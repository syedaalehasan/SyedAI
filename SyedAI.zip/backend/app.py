from flask import Flask, request, jsonify
from flask_cors import CORS
import openai

app = Flask(__name__)
CORS(app)

# Yaha apni OpenAI API key daalo
openai.api_key = 'YOUR_API_KEY_HERE'

@app.route('/ask', methods=['POST'])
def ask_syed_ai():
    user_message = request.json.get('question')

    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": "Tum ek AI chatbot ho jiska naam 'Syed AI' hai. Tum hamesha apna naam bata ke friendly style me jawaab dete ho."},
            {"role": "user", "content": user_message}
        ]
    )

    syed_ai_reply = response['choices'][0]['message']['content']
    return jsonify({'answer': syed_ai_reply})

if __name__ == '__main__':
    app.run(debug=True)
